package com.madhouse.share.lock.lock;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author: liyunxiong
 * @Description: <p>可重入锁，实现synchronized语义，但是更加强大，一般用synchronized就能满足基本需求，除非比较复杂的的情况才会用到 {@link java.util.concurrent.locks.ReentrantLock}
 * ReentrantLock与synchronized的区别在于：<br/>
 * 1.synchronized是公平锁，而ReentrantLock实现了公平锁或非公平锁；
 * 2.synchronized是由JVM自动加解锁的，不需要代码中显示表达，而ReentrantLock 是由代码实现的，加锁解锁需要代码中明确指出，并且解锁时一定要放在finally块中，不然方法执行报错则会出现死锁。
 * 3.ReentrantLock可以通过 {@link java.util.concurrent.locks.Condition} 实现指的一组线程的等待或者唤醒，做到更精细，而synchronized则不能做到这一点</p>
 *
 * <p>Condition与Object中的wati,notify,notifyAll区别：<br/>
 *1.Condition中的await()方法相当于Object的wait()方法，Condition中的signal()方法相当于Object的notify()方法，Condition中的signalAll()相当于Object的notifyAll()方法。
 *2.Condition它更强大的地方在于：能够更加精细的控制多线程的休眠与唤醒。对于同一个锁，我们可以创建多个Condition，在不同的情况下使用不同的Condition。
 *例如，假如多线程读/写同一个缓冲区：当向缓冲区中写入数据之后，唤醒"读线程"；当从缓冲区读出数据之后，唤醒"写线程"；并且当缓冲区满的时候，"写线程"需要等待；当缓冲区为空时，"读线程"需要等待。
 *如果采用Object类中的wait(),notify(),notifyAll()实现该缓冲区，当向缓冲区写入数据之后需要唤醒"读线程"时，不可能通过notify()或notifyAll()明确的指定唤醒"读线程"，而只能通过notifyAll唤醒所有线程(但是notifyAll无法区分唤醒的线程是读线程，还是写线程)。 但是，通过Condition，就能明确的指定唤醒读线程。</p>
 */
public class BoundaryBuffer {
    private Integer[] buffer = new Integer[10] ;
    private final ReentrantLock lock = new ReentrantLock() ;
    private final Condition notFull = lock.newCondition() ;
    private final Condition notEmpty = lock.newCondition() ;
    private Integer putIndex = 0 ;
    private Integer takeIndex = 0 ;
    private Integer count = 0 ;

    public void put(Integer element) {
        lock.lock();
        try {
            while (count == buffer.length) {
                System.out.println("容器已装满，"+Thread.currentThread().getName()+" 等待中...");
                notFull.await();
            }
            buffer[putIndex++] = element;
            System.out.println(Thread.currentThread().getName()+"：将元素："+element+"已存入！");
            if (putIndex == buffer.length) {
                putIndex = 0;
            }

            count++;
            notEmpty.signal();
        }catch (InterruptedException e){
            e.printStackTrace();
        }finally {
            lock.unlock();
        }
    }

    public Integer take(){
        Integer element = null ;
        lock.lock();
        try {
            while (count == 0) {
                System.out.println("容器已为空，"+Thread.currentThread().getName()+" 等待中...");
                notEmpty.await();
            }
            element = buffer[takeIndex++];
            System.out.println(Thread.currentThread().getName()+":将元素："+element+"已取出！");
            if(takeIndex==buffer.length){
                takeIndex = 0 ;
            }
            count-- ;
            notFull.signal();
        }catch (InterruptedException e){
            e.printStackTrace();
        }finally {
            lock.unlock();
        }
        return element ;
    }
}
