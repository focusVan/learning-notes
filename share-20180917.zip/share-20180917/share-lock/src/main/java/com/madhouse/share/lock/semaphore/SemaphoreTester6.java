package com.madhouse.share.lock.semaphore;

import java.util.concurrent.Semaphore;

/**
 * @author: liyunxiong
 * @Description: 信号量测试代码，生产者和消费者协作，生产者生产商品，消费者消费商品。
 * 用例逻辑：
 * 假设一家四口，爸爸妈妈，儿子女儿，一个盘子，且一个盘子里面只能装一个水果，妈妈往盘子中放苹果，爸爸往盘子中放橘子，女儿只从盘子中拿苹果吃，儿子只从盘子中拿橘子吃
 */
public class SemaphoreTester6 {

    public static void main(String[] args){
        final Semaphore dishSemaphore = new Semaphore(1);
        final Semaphore sonSemaphore = new Semaphore(0);
        final Semaphore girlSemaphore = new Semaphore(0);
        final int count = 10 ;
        Runnable father = ()->{
            int proCount = count ;
            while (proCount > 0) {
                try {
                    dishSemaphore.acquire();
                    System.out.println("爸爸：往盘子中放了一个橘子 ！");
                    Thread.sleep(500);
                    sonSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                proCount -- ;
            }
        } ;

        Runnable mother = ()->{
            int proCount = count ;
            while (proCount > 0) {
                try {
                    dishSemaphore.acquire();
                    System.out.println("妈妈：往盘子中放了一个苹果 ！");
                    Thread.sleep(500);
                    girlSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                proCount -- ;
            }
        } ;

        Runnable son = ()->{
            int conCount = count ;
            while (conCount > 0) {
                try {
                    sonSemaphore.acquire();
                    System.out.println("儿子：从盘子中拿走一个橘子 ！");
                    Thread.sleep(500);
                    dishSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                conCount -- ;
            }
        } ;

        Runnable girl = ()->{
            int conCount = count ;
            while (conCount > 0) {
                try {
                    girlSemaphore.acquire();
                    System.out.println("女儿：从盘子中拿走一个苹果 ！");
                    Thread.sleep(500);
                    dishSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                conCount -- ;
            }
        } ;

        Thread fatherThread= new Thread(father);
        Thread motherThread = new Thread(mother);
        Thread sonThread = new Thread(son);
        Thread girlThread = new Thread(girl);
        fatherThread.start();
        motherThread.start();
        sonThread.start();
        girlThread.start();
        try {
            fatherThread.join(1000);
            motherThread.join(1000);
            sonThread.join(1000);
            girlThread.join(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

