package com.madhouse.share.lock.lock;

/**
 * @author: liyunxiong
 * @Description: {@link java.util.concurrent.locks.StampedLock} 是对 {@link java.util.concurrent.locks.ReentrantReadWriteLock} 的改进
 * 因为ReentrantReadWriteLock的读锁与写锁是互斥的,以及写锁与写锁是互斥的,则在读线程远比写线程多的情况下,会导致写线程可能一直拿不到锁,而导致写线程的饥饿.
 * StampedLock支持读锁写锁不互斥,而而消除了写线程饥饿的现象.
 * <p>StampedLock是Java 8中引入的一种新的锁机制。读写锁虽然分离了读和写的功能，使得读与读之间可以完全并发。但是，读和写之间依然是冲突的。读锁会完全阻塞写锁，它使用的依然是悲观锁的策略，如果有大量的读线程，它也有可能引起写线程的“饥饿”。
 * 而StampedLock提供了一种乐观的读策略。这种乐观策略的锁非常类似无锁的操作，使得乐观锁完全不会阻塞写线程。</p>
 * <p>该类是一个读写锁的改进，它的思想是读写锁中读不仅不阻塞读，同时也不应该阻塞写。
 * 读不阻塞写的实现思路：
 * 在读的时候如果发生了写，则应当重读而不是在读的时候直接阻塞写！
 * 因为在读线程非常多而写线程比较少的情况下，写线程可能发生饥饿现象，也就是因为大量的读线程存在并且读线程都阻塞写线程，
 * 因此写线程可能几乎很少被调度成功！当读执行的时候另一个线程执行了写，则读线程发现数据不一致则执行重读即可。所以读写都存在的情况下，
 * 使用StampedLock就可以实现一种无障碍操作，即读写之间不会阻塞对方，但是写和写之间还是阻塞的！</p>
 */
public class StampedLockTester1 {
    private static final Double MOVE_X = 1D ;
    private static final Double MOVE_Y = 1D ;
    private static final Integer MOVE_TIMES = 10 ;

    public static void main(String[] args) {
        Point point = new Point();
        Runnable runnable1 = () -> {
            for (int i = 0; i < MOVE_TIMES; i++) {
                point.move(MOVE_X, MOVE_Y);
                Double distance = point.distanceFromOrigin();
                System.out.println("当前坐标点距离原点的距离为:" + distance);
            }
        };
        Runnable runnable2 = () -> {
            for (int i = 0; i < MOVE_TIMES; i++) {
                point.move(MOVE_X, MOVE_Y);
                Double distance = point.distanceFromOrigin();
                System.out.println("当前坐标点距离原点的距离为:" + distance);
            }
        };

        Thread thread1 = new Thread(runnable1,"线程1");
        Thread thread2 = new Thread(runnable2,"线程2");
        thread1.start();
        thread2.start();
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
