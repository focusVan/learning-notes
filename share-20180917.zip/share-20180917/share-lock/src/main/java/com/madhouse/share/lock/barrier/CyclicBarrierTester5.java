package com.madhouse.share.lock.barrier;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

/**
 * @author: liyunxiong
 * @Description: 栅栏，通过栅栏做并发测试
 */
public class CyclicBarrierTester5 {

    public static void main(String[] args){
        Integer threadNum = 100 ;
        final CyclicBarrier barrier = new CyclicBarrier(threadNum) ;
        final CountDownLatch latch = new CountDownLatch(threadNum) ;
        System.out.println("测试开始！") ;
        for(int i = 0 ; i < threadNum ; i ++){
            TestCase testCase = new TestCase(barrier,latch);
            testCase.start();
        }
        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("测试完成！") ;
    }
}
