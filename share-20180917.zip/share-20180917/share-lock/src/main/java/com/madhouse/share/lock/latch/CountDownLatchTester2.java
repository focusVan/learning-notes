package com.madhouse.share.lock.latch;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.CountDownLatch;

/**
 * @author: liyunxiong
 * @Description: 闭锁，一般用于某个线程A等待若干个其他线程执行完任务之后，它才执行
 * 此例逻辑为：主线程执行操作的过程中需要读取某一文件的内容，开启一个子线程去并发读取，等待子线程读取并返回内容后主线程再继续执行。
 */
public class CountDownLatchTester2 {
    public static void main(String[] args){
        System.out.println("主线程开始工作...");

        final CountDownLatch latch = new CountDownLatch(1);
        final String filePath = "/home/liyunxiong/cerberus.sh" ;
        Writer writer = new Writer(filePath, latch);

        System.out.println("子线程等待读文件线程读入文件内容...");
        writer.start();
        try {
            latch.await();
            System.out.println("子线程读文件线程读入文件内容完成.");
            String content = writer.getContent();
            System.out.println("子线程读入的文件内容为：\n"+content);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("主线程工作完成.");
    }
}

class Writer extends Thread{
    private String filePath ;
    private String content ;
    private CountDownLatch latch ;

    public Writer(String filePath,CountDownLatch latch){
        this.filePath = filePath ;
        this.latch = latch ;
    }

    @Override
    public void run(){
        File file = new File(this.filePath);
        try {
            FileInputStream stream = new FileInputStream(file);
            int available = stream.available();
            byte[] content = new byte[available] ;
            stream.read(content);
            this.content = new String(content) ;
            this.latch.countDown();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getContent() {
        return content;
    }
}
