package com.madhouse.share.lock.barrier;

import com.madhouse.share.lock.util.HttpclientUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

/**
 * @author: liyunxiong
 * @Description:
 */
public class TestCase extends Thread{
    private CyclicBarrier barrier ;
    private CountDownLatch latch ;
    private final String url = "http://172.16.25.106:9090/campaign/list/campaign" ;
    private static final Map<String,String> headers = new HashMap<>(3) ;

    static {
        if(Objects.nonNull(headers)){
            headers.put("X-User-Id","19") ;
            headers.put("X-Language","zh_cn") ;
            headers.put("X-Timezone","8") ;
        }
    }
    public TestCase(CyclicBarrier barrier,CountDownLatch latch){
        this.barrier = barrier ;
        this.latch = latch ;
    }

    @Override
    public void run(){
        try {
            this.barrier.await() ;
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (BrokenBarrierException e) {
            e.printStackTrace();
        }
        Integer result = HttpclientUtil.doGet(url, headers);
        System.out.println(Thread.currentThread().getName()+"执行的结果为："+result) ;
        this.latch.countDown();
    }

}
