package com.madhouse.share.lock.lock;

import java.util.concurrent.locks.StampedLock;

/**
 * @author: liyunxiong
 * @Description: {@link java.util.concurrent.locks.StampedLock} 是对 {@link java.util.concurrent.locks.ReentrantReadWriteLock} 的改进
 * 因为ReentrantReadWriteLock的读锁与写锁是互斥的,以及写锁与写锁是互斥的,则在读线程远比写线程多的情况下,会导致写线程可能一直拿不到锁,而导致写线程的饥饿.
 * StampedLock支持读锁写锁不互斥,而而消除了写线程饥饿的现象.
 * <p>StampedLock是Java 8中引入的一种新的锁机制。读写锁虽然分离了读和写的功能，使得读与读之间可以完全并发。但是，读和写之间依然是冲突的。读锁会完全阻塞写锁，它使用的依然是悲观锁的策略，如果有大量的读线程，它也有可能引起写线程的“饥饿”。
 * 而StampedLock提供了一种乐观的读策略。这种乐观策略的锁非常类似无锁的操作，使得乐观锁完全不会阻塞写线程。</p>
 * <p>该类是一个读写锁的改进，它的思想是读写锁中读不仅不阻塞读，同时也不应该阻塞写。
 * 读不阻塞写的实现思路：
 * 在读的时候如果发生了写，则应当重读而不是在读的时候直接阻塞写！
 * 因为在读线程非常多而写线程比较少的情况下，写线程可能发生饥饿现象，也就是因为大量的读线程存在并且读线程都阻塞写线程，
 * 因此写线程可能几乎很少被调度成功！当读执行的时候另一个线程执行了写，则读线程发现数据不一致则执行重读即可。所以读写都存在的情况下，
 * 使用StampedLock就可以实现一种无障碍操作，即读写之间不会阻塞对方，但是写和写之间还是阻塞的！</p>
 */
public class Point {
    private Double x = 0D ;
    private Double y = 0D ;
    private final StampedLock lock = new StampedLock() ;

    /**
     * 移动当前点的位置
     * 写锁
     * @param deltaX x坐标点
     * @param deltaY y坐标点
     */
    public void move(Double deltaX,Double deltaY){
        long stamp = lock.writeLock();
        try{
            this.x += deltaX ;
            this.y += deltaY ;
            System.out.println(Thread.currentThread().getName()+":将当前位置移动到 [x:"+this.x+", y:"+this.y+"]") ;
        }finally {
            lock.unlockWrite(stamp);
        }
    }

    /**
     * 获取当前点距离原点的距离
     * 使用乐观锁,如果获取的数据被改过,则升级乐观锁为悲观锁,并重读数据
     * @return 当前点距离原点的距离
     */
    public Double distanceFromOrigin(){
        //获取乐观锁
        long stamp = lock.tryOptimisticRead();
        Double currentX = this.getX();
        Double currentY = this.getY();
        //检验在获取数据的过程中数据是否被改变了,改变了则升级为悲欢锁并重读数据
        if(!lock.validate(stamp)){
            stamp = lock.readLock();
            try{
                currentX = this.getX() ;
                currentY = this.getY() ;
            }finally {
                lock.unlockRead(stamp);
            }
        }
        double distance = Math.sqrt(currentX * currentX + currentY * currentY);
        //取小数点后两位
        double dist = (int) (distance * 100) / 100D;
        return dist ;
    }

    /**
     * 如果当前点在原点的位置上,则移动当前点的位置到新的坐标位置
     * @param newX 新的x坐标
     * @param newY 新的y坐标
     */
    public void moveIfAtOrigin(Double newX,Double newY){
        //获取悲观锁,读取当前坐标点的数据,保证了读入的当前点的数据是正确的
        long stamp = lock.readLock();
        try{
            //判断当前点是否在原点上,如果是则移动,否则什么也不做
            while (this.x==0 && this.y==0){
                //如果当前点确实在原点上,则试图将读锁转为写锁
                long writeStamp = lock.tryConvertToWriteLock(stamp);
                /*如果成功转为写锁,则writeStamp不等于0,如果等于0则表示没有转换成功,转换成功的话则直接移动当前点到新的位置并退出循环.
                 *否则释放当前持有的读锁,并重新阻塞获取写锁
                 */
                if(writeStamp != 0L){
                    stamp = writeStamp ;
                    this.x = newX ;
                    this.y = newY ;
                    System.out.println(Thread.currentThread().getName()+":将当前位置移动到 [x:"+this.x+", y:"+this.y+"]") ;
                    break;
                }else {
                    //显示释放读锁
                    lock.unlockRead(stamp);
                    //显示的阻塞的获取写锁,当再次进入循环时,writeStamp的值将不等于0
                    stamp = lock.writeLock();
                }
            }
        }finally {
            //释放读锁或者写锁
            lock.unlock(stamp);
        }
    }

    public Double getX() {
        return x;
    }

    public void setX(Double x) {
        this.x = x;
    }

    public Double getY() {
        return y;
    }

    public void setY(Double y) {
        this.y = y;
    }
}
