package com.madhouse.share.lock.lock;

/**
 * @author: liyunxiong
 * @Description:
 */
public class Person {
    private String name ;
    private static String nickName ;

    /**
     * 使用同步实例方法保证方法的安全性
     * @param name
     */
    public synchronized void setName(String name){
        this.name = name ;
    }

    /**
     * 使用同步代码块保证方法的安全性
     * @return
     */
    public String getName(){
        synchronized (this) {
            return this.name ;
        }
    }

    /**
     * 使用同步静态方法保证方法的安全性
     * @return
     */
    public synchronized static String getNickName(){
        return nickName ;
    }

    /**
     * 使用同步静态代码块保证安全性
     * @param nickName
     */
    public static void setNickName(String nickName){
        synchronized (Person.class){
            Person.nickName = nickName ;
        }
    }
}
