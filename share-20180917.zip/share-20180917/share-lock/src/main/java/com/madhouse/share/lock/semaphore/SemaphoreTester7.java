package com.madhouse.share.lock.semaphore;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;

/**
 * @author: liyunxiong
 * @Description: 信号量测试代码，生产者和消费者协作，生产者每生产一个商品，消费者才能消费一个商品。
 * 如果生产者没有生商品则消费者不能消费，需等待生产者生产出商品；
 * 如果消费者没有消费完商品，则生产者不能生产，需要等待消费者消费完后才可以生产
 */
public class SemaphoreTester7 {

    public static void main(String[] args){
        final Semaphore proSemaphore = new Semaphore(1);
        final Semaphore conSemaphore = new Semaphore(0);
        final CountDownLatch latch = new CountDownLatch(2) ;
        final int count = 10 ;

        Producter producter = new Producter(proSemaphore, conSemaphore, latch, count);
        Consumer consumer = new Consumer(proSemaphore, conSemaphore, latch, count);
        producter.start();
        consumer.start();
        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("已经完成生产和消费！") ;
    }

}

