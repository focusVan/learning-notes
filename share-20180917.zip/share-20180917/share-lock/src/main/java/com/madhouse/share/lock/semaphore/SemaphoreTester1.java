package com.madhouse.share.lock.semaphore;

import java.util.concurrent.Semaphore;

/**
 * @author: liyunxiong
 * @Description: 信号量测试代码，生产者和消费者协作，生产者每生产一个商品，消费者才能消费一个商品。
 * 如果生产者没有生商品则消费者不能消费，需等待生产者生产出商品；
 * 如果消费者没有消费完商品，则生产者不能生产，需要等待消费者消费完后才可以生产
 */
public class SemaphoreTester1 {

    public static void main(String[] args){
        final Semaphore proSemaphore = new Semaphore(1);
        final Semaphore conSemaphore = new Semaphore(0);
        final int count = 10 ;
        Runnable producter = ()->{
            int proCount = count ;
            while (proCount > 0) {
                try {
                    proSemaphore.acquire();
                    System.out.println("生产一个商品 ！");
                    Thread.sleep(500);
                    conSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                proCount -- ;
            }
        } ;

        Runnable consumer = ()->{
            int conCount = count ;
            while (conCount > 0) {
                try {
                    conSemaphore.acquire();
                    System.out.println("消费一个商品 ！");
                    Thread.sleep(500);
                    proSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                conCount -- ;
            }
        } ;

        Thread proThread = new Thread(producter);
        Thread conThread = new Thread(consumer);
        proThread.start();
        conThread.start();
        try {
            proThread.join(1000);
            conThread.join(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

