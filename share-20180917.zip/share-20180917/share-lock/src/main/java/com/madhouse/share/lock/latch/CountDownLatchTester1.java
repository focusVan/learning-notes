package com.madhouse.share.lock.latch;

import java.util.concurrent.CountDownLatch;

/**
 * @author: liyunxiong
 * @Description: 闭锁，一般用于某个线程A等待若干个其他线程执行完任务之后，它才执行
 */
public class CountDownLatchTester1 {
    public static void main(String[] args){
        CountDownLatch latch = new CountDownLatch(3);
        Runnable worker1 = ()->{
            System.out.println("工作线程1：开始工作.");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("工作线程1：工作结束.");
            latch.countDown();
        };
        Runnable worker2 = ()->{
            System.out.println("工作线程2：开始工作.");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("工作线程2：工作结束.");
            latch.countDown();
        };
        Runnable worker3 = ()->{
            System.out.println("工作线程3：开始工作.");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("工作线程3：工作结束.");
            latch.countDown();
        };

        Thread worker1Thread = new Thread(worker1);
        Thread worker2Thread = new Thread(worker2);
        Thread worker3Thread = new Thread(worker3);

        System.out.println("等待子线程完成工作...");
        worker1Thread.start();
        worker2Thread.start();
        worker3Thread.start();
        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("子线程已完成所有工作，主线程结束.");
    }
}
