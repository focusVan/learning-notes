package com.madhouse.share.lock.barrier;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Semaphore;

/**
 * @author: liyunxiong
 * @Description: 模拟两个棋手下棋的操作
 */
public class ChessPlayer extends Thread{
    private Semaphore whiteSemaphore ;
    private Semaphore blackSemaphore ;
    private CyclicBarrier barrier ;
    private CountDownLatch latch ;
    private Integer count ;

    private String playerName ;

    public ChessPlayer(Semaphore whiteSemaphore,Semaphore blackSemaphore,CyclicBarrier barrier,CountDownLatch latch,Integer count){
        this.whiteSemaphore = whiteSemaphore ;
        this.blackSemaphore = blackSemaphore ;
        this.barrier = barrier ;
        this.latch = latch ;
        this.count = count ;
    }

    @Override
    public void run(){
        System.out.println(playerName+"到位！") ;
        try {
            barrier.await() ;
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (BrokenBarrierException e) {
            e.printStackTrace();
        }
        try {
            while (count > 0) {
                whiteSemaphore.acquire();
                System.out.println(playerName + "下了一步棋.");
                blackSemaphore.release();
                count -- ;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }finally {
            latch.countDown();
        }
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }
}
