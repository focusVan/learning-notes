package com.madhouse.share.lock.lock;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * @author: liyunxiong
 * @Description: 可重入读写锁：读线程之间不互斥，写线程之间互斥，写线程与读线程之间互斥，此锁在大量读取少量写入的场景下，效率更高，因为读线程之间不互斥。
 * {@link ReentrantReadWriteLock} 与 {@link java.util.concurrent.locks.ReentrantLock} 的实现都是独立的，两者之间不存继承等关系
 * ReentrantReadWriteLock 写线程在持有写锁的情况下，可以降级成读锁，反之不行，即读锁不能降级为写锁.
 * ReentrantReadWriteLock只有写锁支持{@link Condition},读锁不支持.
 * <p>对象的方法中一旦加入synchronized修饰，则任何时刻只能有一个线程访问synchronized修饰的方法。
 * 假设有个数据对象拥有写方法与读方法，多线程环境中要想保证数据的安全，需对该对象的读写方法都要加入 synchronized同步块。
 * 这样任何线程在写入时，其它线程无法读取与改变数据；如果有线程在读取时，其他线程也无法读取或写入。
 * 这种方式在写入操作远大于读操作时，问题不大，而当读取远远大于写入时，会造成性能瓶颈，因为此种情况下读取操作是可以同时进行的，而加锁操作限制了数据的并发读取。</p>
 * <p>ReadWriteLock解决了这个问题，当写操作时，其他线程无法读取或写入数据，而当读操作时，其它线程无法写入数据，但却可以读取数据 。</p>
 * <p>Lock比传统线程模型中的synchronized方式更加面向对象，与生活中的锁类似，锁本身也应该是一个对象。
 * 两个线程执行的代码片段要实现同步互斥的效果，它们必须用同一个Lock对象。</p>
 * <p>读写锁：分为读锁和写锁，多个读锁不互斥，读锁与写锁互斥，这是由jvm自己控制的，你只要上好相应的锁即可。
 * 如果你的代码只读数据，可以很多人同时读，但不能同时写，那就上读锁；如果你的代码修改数据，只能有一个人在写，且不能同时读取，那就上写锁。
 * 总之，读的时候上读锁，写的时候上写锁！</p>
 * <p>ReentrantReadWriteLock会使用两把锁来解决问题，一个读锁，一个写锁<br/>
 * 线程进入读锁的前提条件：<br/>
 * 没有其他线程的写锁，<br/>
 * 没有写请求或者有写请求，但调用线程和持有锁的线程是同一个<br/>
 * 线程进入写锁的前提条件：<br/>
 * 没有其他线程的读锁<br/>
 * 没有其他线程的写锁<br/>
 * 到ReentrantReadWriteLock，首先要做的是与ReentrantLock划清界限。
 * 它和后者都是单独的实现，彼此之间没有继承或实现的关系。然后就是总结这个锁机制的特性了： <br/>
 * (a).重入方面其内部的WriteLock可以获取ReadLock，但是反过来ReadLock想要获得WriteLock则永远都不要想。
 * (b).WriteLock可以降级为ReadLock，顺序是：先获得WriteLock再获得ReadLock，然后释放WriteLock，这时候线程将保持Readlock的持有。
 * 反过来ReadLock想要升级为WriteLock则不可能，为什么？参看(a).<br/>
 * (c).ReadLock可以被多个线程持有并且在作用时排斥任何的WriteLock，而WriteLock则是完全的互斥。
 * 这一特性最为重要，因为对于高读取频率而相对较低写入的数据结构，使用此类锁同步机制则可以提高并发量。<br/>
 * (d).不管是ReadLock还是WriteLock都支持Interrupt，语义与ReentrantLock一致。
 * (e).WriteLock支持Condition并且与ReentrantLock语义一致，而ReadLock则不能使用Condition，否则抛出UnsupportedOperationException异常。</p>
 * 例：数字容器类，用来存放或者取数字
 */
public class NumberContainer2 {
    private final ReentrantLock lock = new ReentrantLock();
    private List<Integer> container = new ArrayList<>();

    public void put(Integer num) {
        lock.lock();
        try {
            container.add(num);
            System.out.println(Thread.currentThread().getName() + ":将数字"+num+"存入容器.") ;
        } finally {
            lock.unlock();
        }
    }

    public Integer get(Integer index) {
        lock.lock();
        try {
            if (index >= 0 && index < container.size()) {
                Integer num = container.get(index);
                System.out.println(Thread.currentThread().getName() + ":将数字"+num+"取出容器.") ;
                return num;
            }
        } finally {
            lock.unlock();
        }
        return null;
    }

    public Integer size(){
        lock.lock();
        try{
            return container.size() ;
        }finally {
            lock.unlock();
        }
    }
}
