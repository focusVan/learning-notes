package com.madhouse.share.lock.semaphore;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;

/**
 * @author: liyunxiong
 * @Description: 生产者，生产商品，每次只生产一个商品，只有生产的商品被消费者消费后才可以继续生产。
 */
public class Producter extends Thread{
    private Semaphore proSemaphore ;
    private Semaphore conSemaphore ;
    private CountDownLatch latch ;
    private Integer count ;

    public Producter(Semaphore proSemaphore,Semaphore conSemaphore,CountDownLatch latch,Integer count){
        this.proSemaphore = proSemaphore ;
        this.conSemaphore = conSemaphore ;
        this.latch = latch ;
        this.count = count ;
    }

    @Override
    public void run(){
        try {
            while(count > 0) {
                proSemaphore.acquire();
                Thread.sleep(500);
                System.out.println("生产者：生产了一个商品！");
                conSemaphore.release();
                count -- ;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }finally {
            latch.countDown();
        }
    }
}
