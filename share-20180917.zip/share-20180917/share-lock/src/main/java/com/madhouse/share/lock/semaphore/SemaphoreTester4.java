package com.madhouse.share.lock.semaphore;

import java.util.concurrent.Semaphore;

/**
 * @author: liyunxiong
 * @Description: 信号量测试代码，生产者和消费者协作，生产者生产商品，消费者消费商品。
 * 生产者生产出来的商品放在一个容器中，一个容器可容纳n个商品，如果容器已经放满，则不能继续生产，需要等待消费者消费。
 * 消费者消费商品，如果容器中的端口为空，则不能继续消费，需要等待生产者生产商品后方可消费。
 * 生产品每生产一个商品放入容器中，则容器的可放商品数减1，消费者每消费一个商品，则容器的可放端口的数量加1
 * 此例设容器可存放商品数量为3个,两个生产者，两个消费者
 */
public class SemaphoreTester4 {

    public static void main(String[] args){
        final Semaphore proSemaphore = new Semaphore(3);
        final Semaphore conSemaphore = new Semaphore(0);
        final int count = 10 ;
        Runnable producter1 = ()->{
            int proCount = count ;
            while (proCount > 0) {
                try {
                    proSemaphore.acquire();
                    System.out.println("生产者1：生产一个商品 ！");
                    Thread.sleep(500);
                    conSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                proCount -- ;
            }
        } ;

        Runnable producter2 = ()->{
            int proCount = count ;
            while (proCount > 0) {
                try {
                    proSemaphore.acquire();
                    System.out.println("生产者2：生产一个商品 ！");
                    Thread.sleep(500);
                    conSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                proCount -- ;
            }
        } ;

        Runnable consumer1 = ()->{
            int conCount = count ;
            while (conCount > 0) {
                try {
                    conSemaphore.acquire();
                    System.out.println("消费者1：消费一个商品 ！");
                    Thread.sleep(500);
                    proSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                conCount -- ;
            }
        } ;

        Runnable consumer2 = ()->{
            int conCount = count ;
            while (conCount > 0) {
                try {
                    conSemaphore.acquire();
                    System.out.println("消费者2：消费一个商品 ！");
                    Thread.sleep(500);
                    proSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                conCount -- ;
            }
        } ;

        Thread proThread1 = new Thread(producter1);
        Thread proThread2 = new Thread(producter2);
        Thread conThread1 = new Thread(consumer1);
        Thread conThread2 = new Thread(consumer2);
        proThread1.start();
        proThread2.start();
        conThread1.start();
        conThread2.start();
        try {
            proThread1.join(1000);
            proThread2.join(1000);
            conThread1.join(1000);
            conThread2.join(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

