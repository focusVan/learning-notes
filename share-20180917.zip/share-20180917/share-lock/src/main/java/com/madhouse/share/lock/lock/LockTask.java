package com.madhouse.share.lock.lock;

import java.util.concurrent.locks.ReentrantLock;

/**
 * @author: liyunxiong
 * @Description:
 */
public class LockTask {
    private final ReentrantLock lock = new ReentrantLock() ;

    public void doSomeThing(Integer times){
        lock.lock();
        try{
            System.out.println(Thread.currentThread().getName()+":get the lock.");
            System.out.println(Thread.currentThread().getName()+": "+times+" time do something...");
        }finally {
            lock.unlock();
            System.out.println(Thread.currentThread().getName()+":release the lock.");
        }
    }
}
