package com.madhouse.share.lock.semaphore;

import java.util.concurrent.Semaphore;

/**
 * @author: liyunxiong
 * @Description: 信号量测试代码，生产者和消费者协作，两个生产者生产商品，一个消费者消费商品。
 * 每个生产者每次只能生产一个端口，每个消费者一次只能消费一个商品。
 * 一个生产者在生产时另一个生产者需要等待。
 * 如果生产者没有生商品则消费者不能消费，需等待生产者生产出商品；
 * 如果消费者没有消费完商品，则生产者不能生产，需要等待消费者消费完后才可以生产
 */
public class SemaphoreTester3 {

    public static void main(String[] args){
        final Semaphore proSemaphore = new Semaphore(1);
        final Semaphore conSemaphore = new Semaphore(0);
        final int count = 10 ;
        Runnable producter1 = ()->{
            int proCount1 = count ;
            while (proCount1 > 0) {
                try {
                    proSemaphore.acquire();
                    System.out.println("生产者1：生产一个商品 ！");
                    Thread.sleep(500);
                    conSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                proCount1 -- ;
            }
        } ;

        Runnable producter2 = ()->{
            int proCount2 = count ;
            while (proCount2 > 0) {
                try {
                    proSemaphore.acquire();
                    System.out.println("生产者2：生产一个商品 ！");
                    Thread.sleep(500);
                    conSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                proCount2 -- ;
            }
        } ;

        Runnable consumer = ()->{
            int conCount = 2*count ;
            while (conCount > 0) {
                try {
                    conSemaphore.acquire();
                    System.out.println("消费者：消费一个商品 ！");
                    Thread.sleep(500);
                    proSemaphore.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                conCount -- ;
            }
        } ;

        Thread proThread1 = new Thread(producter1);
        Thread proThread2 = new Thread(producter2);
        Thread conThread = new Thread(consumer);
        proThread1.start();
        proThread2.start();
        conThread.start();
        try {
            proThread1.join(1000);
            proThread2.join(1000);
            conThread.join(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

