package com.madhouse.share.lock.barrier;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

/**
 * @author: liyunxiong
 * @Description: 循环珊栏，用来处理一组线程相互等待到某一状态后，然后一起开始执行某一操作
 */
public class CyclicBarrierTester1 {

    public static void main(String[] args){
        CyclicBarrier cyclicBarrier = new CyclicBarrier(3);
        Runnable runner1 = ()->{
            System.out.println("跑步选手1：到位就绪！") ;
            try {
                cyclicBarrier.await() ;
                System.out.println("跑步选手1：开始跑！") ;
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (BrokenBarrierException e) {
                e.printStackTrace();
            }
        } ;
        Runnable runner2 = ()->{
            System.out.println("跑步选手2：到位就绪！") ;
            try {
                cyclicBarrier.await() ;
                System.out.println("跑步选手2：开始跑！") ;
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (BrokenBarrierException e) {
                e.printStackTrace();
            }
        } ;
        Runnable runner3 = ()->{
            System.out.println("跑步选手3：到位就绪！") ;
            try {
                cyclicBarrier.await() ;
                System.out.println("跑步选手3：开始跑！") ;
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (BrokenBarrierException e) {
                e.printStackTrace();
            }
        } ;

        Thread runThread1 = new Thread(runner1);
        Thread runThread2 = new Thread(runner2);
        Thread runThread3 = new Thread(runner3);
        runThread1.start();
        runThread2.start();
        runThread3.start();
    }
}
