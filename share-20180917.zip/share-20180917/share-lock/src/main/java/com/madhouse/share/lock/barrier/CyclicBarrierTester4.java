package com.madhouse.share.lock.barrier;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Semaphore;

/**
 * @author: liyunxiong
 * @Description: 利用信号量、栅栏、闭锁，模拟两个棋手下围棋。
 * 通过栅栏，保证两个棋手到位后才开始下棋；通过信号量保证两位棋手交替下棋，一人下一步；通过闭锁保证等两位棋手线程下棋结束后主线程宣布结果后再结束。
 */
public class CyclicBarrierTester4 {

    public static void main(String[] args){
        final Semaphore whiteSemaphore = new Semaphore(1) ;
        final Semaphore blackSemaphore = new Semaphore(0) ;
        final CyclicBarrier barrier = new CyclicBarrier(2) ;
        final CountDownLatch latch = new CountDownLatch(2) ;
        final Integer count = 10 ;
        ChessPlayer whitePlayer = new ChessPlayer(whiteSemaphore,blackSemaphore,barrier,latch,count);
        whitePlayer.setPlayerName("白棋棋手");
        ChessPlayer blackPlayer = new ChessPlayer(blackSemaphore,whiteSemaphore,barrier,latch,count);
        blackPlayer.setPlayerName("黑棋棋手");

        System.out.println("准备开始下棋...");
        whitePlayer.start();
        blackPlayer.start();
        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("下棋结束.");
    }
}
