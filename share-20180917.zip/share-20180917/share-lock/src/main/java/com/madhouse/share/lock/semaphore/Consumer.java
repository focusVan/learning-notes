package com.madhouse.share.lock.semaphore;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;

/**
 * @author: liyunxiong
 * @Description: 消费者，消费商品，每次只消费一个商品，只有有商品可消费时才可以消费，否则等待生产者生产。
 */
public class Consumer extends Thread{
    private Semaphore proSemaphore ;
    private Semaphore conSemaphore ;
    private CountDownLatch latch ;
    private Integer count ;

    public Consumer(Semaphore proSemaphore, Semaphore conSemaphore,CountDownLatch latch,Integer count){
        this.proSemaphore = proSemaphore ;
        this.conSemaphore = conSemaphore ;
        this.latch = latch ;
        this.count = count ;
    }

    @Override
    public void run(){
        try {
            while (count > 0) {
                conSemaphore.acquire();
                Thread.sleep(500);
                System.out.println("消费者：消费了一个商品！");
                proSemaphore.release();
                count -- ;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }finally {
            latch.countDown();
        }
    }

}
